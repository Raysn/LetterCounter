package editer;

import javax.swing.JTextArea;

public class SelectAllCommand {
    
    public static void SelectAllCommand(JTextArea area) {
        area.selectAll();
    }
    
}
