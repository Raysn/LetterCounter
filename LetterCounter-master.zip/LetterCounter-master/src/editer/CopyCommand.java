package editer;

import javax.swing.JTextArea;

public class CopyCommand {
    
    public static void CopyCommand(JTextArea area) {
        area.copy();
    }
    
}
