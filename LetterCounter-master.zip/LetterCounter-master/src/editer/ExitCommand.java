package editer;

public class ExitCommand {
    
    public static void ExitCommand() {
        System.exit(0);
    }
    
}
