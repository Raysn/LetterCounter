package editer;

import action.ClearAction;

public class NewCommand {
    
    public static void NewCommand() {
        ClearAction.ClearAction();
    }
    
}
