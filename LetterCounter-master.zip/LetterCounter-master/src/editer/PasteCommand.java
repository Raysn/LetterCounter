package editer;

import javax.swing.JTextArea;

public class PasteCommand {
    
    public static void PasteCommand(JTextArea area) {
        area.paste();
    }
    
}
