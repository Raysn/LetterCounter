package editer;

import javax.swing.JTextArea;

public class CutCommand {
    
    public static void CutCommand(JTextArea area) {
        area.cut();
    }
    
}
